export interface IPost {
  title: string
  content: string
}

